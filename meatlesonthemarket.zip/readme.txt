This is the original master of this album. If you would like the latest remaster, go to:
https://housemoonsprinter.bandcamp.com/album/meatles-on-the-market-remastered