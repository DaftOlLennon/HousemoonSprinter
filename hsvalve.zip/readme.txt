Hey, hey, hey! Stay outta my download shed!
So, you like "Open Your Valve" enough to use it in your actual Valve games?
Well then here you go!

This magical README assumes you already have a Valve game, if not go get one man! (I'd recommend TF2, it's free!)
(Can be used with any original Source game, Source SDK Base, or maybe fan mods but I'm not in the mood to test...)

This guide also assumes you have the latest version of Steam for Windows 10/8/7.
Windows XP/Vista work too if you copy the game files and play offline, you decide where you put it...

Guide:

* Step 1: Navigate to where you installed the Source game you want to use.
(The default location being "C:/Program Files (x86)/Steam/steamapps/common/*Game Name*" )

* Step 2: Go into the game folder and then the specific folder/folders, shown here:

  * Most Games: "hl2/media/" for .bik and "*gamename*/media/" for .txt

  * Portal 2: "portal2_dlc2/media/" for .bik and "portal2/media/" for .txt


* Step 3: Copy the respective file depending on your game:

  * Most Games: Copy "hsvalve_sd.bik" from the very zip, it shouldn't conflict, if it does then what are you doing installing this twice.

  * Portal 2: Portal 2 uses the newest Valve intro and requires "hsvalve_hd.bik" instead, installation instructions are the same.

* Step 4: Edit the "startupvids.txt" to point to the new video.