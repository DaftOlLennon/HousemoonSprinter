This is the original master of this song. If you would like the latest remaster, go to:
https://housemoonsprinter.bandcamp.com/album/strawberry-fields-forever-remastered